
/* 
 * File:   atun_cycle.h
 * Author: 19020107
 *
 * Created on May 16, 2018, 10:41 AM
 */

#ifndef ATUN_CYCLE_H
#define ATUN_CYCLE_H

void atun_master_process_cycle();


#endif /* ATUN_CYCLE_H */

